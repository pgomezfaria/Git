public class Hola { 
    public static void main (String args[]){ 
        System.out.println("Welcome to de Java World"); 
        System.out.println("I have no more branches to commit, said the Ent")
    } 
}
