#!/bin/bash 
echo Listado completo
ls -l
